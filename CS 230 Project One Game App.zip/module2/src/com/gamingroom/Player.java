package com.gamingroom;

/**
 * A simple class to hold information about a player
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a player is
 * created.
 * </p>
 * @Daniel Collins daniel.collins6@snhu.edu
 *
 */
public class Player extends Entity {
	
	 
	public Player(long id, String name) { // Constructor with an identifier and name
		super(id, name);
	}

}

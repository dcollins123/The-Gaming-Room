package com.gamingroom;

public abstract class Entity {

    protected long id;  // Protected members inherited by subclasses
    protected String name;

    protected Entity(long id, String name) { //Protected constructor with id and name
        this.id = id;
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String toString() {
        return this.getClass().getSimpleName() + " [id=" + id + ", name=" + name + "]";
    }
}

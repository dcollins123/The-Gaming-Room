package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.Authorizer;
import jakarta.ws.rs.container.ContainerRequestContext;
import org.checkerframework.checker.nullness.qual.Nullable;

public class GameAuthorizer implements Authorizer<GameUser> {
    public boolean authorize(GameUser user, String role) {	//REMOVED: @OVERIDE to fix error, a questionable decision
    	
        // Finish the authorize method based on BasicAuth Security Example
    	return user.getRoles() != null && user.getRoles().contains(role);
    }

	@Override
	public boolean authorize(GameUser principal, String role, @Nullable ContainerRequestContext requestContext) {
		// TODO Auto-generated method stub
		return false;
	}
}
package com.gamingroom.gameauth;

import io.dropwizard.core.Configuration;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.*;
import jakarta.validation.constraints.*;

public class GameAuthConfiguration extends Configuration {

}